(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Documents_FRONTEND_quiz_daftar-game-favorit_2382f5f6._.js"
],
    source: "dynamic"
});
