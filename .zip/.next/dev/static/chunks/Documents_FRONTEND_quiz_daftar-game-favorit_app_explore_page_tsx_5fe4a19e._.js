(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/cf31d_next_82820e65._.js",
  "static/chunks/Documents_FRONTEND_quiz_daftar-game-favorit_app_0679f164._.js"
],
    source: "dynamic"
});
