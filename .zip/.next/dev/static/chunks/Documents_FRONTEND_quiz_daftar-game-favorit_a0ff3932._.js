(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f78c8f5a._.js",
  "static/chunks/cf31d_next_dist_compiled_react-dom_17995ef7._.js",
  "static/chunks/cf31d_next_dist_compiled_react-server-dom-turbopack_3135ecb8._.js",
  "static/chunks/cf31d_next_dist_compiled_next-devtools_index_3692facb.js",
  "static/chunks/cf31d_next_dist_compiled_0ae7872c._.js",
  "static/chunks/cf31d_next_dist_client_b99f1d8e._.js",
  "static/chunks/cf31d_next_dist_9f372e28._.js",
  "static/chunks/cf31d_@swc_helpers_cjs_aac32042._.js"
],
    source: "entry"
});
