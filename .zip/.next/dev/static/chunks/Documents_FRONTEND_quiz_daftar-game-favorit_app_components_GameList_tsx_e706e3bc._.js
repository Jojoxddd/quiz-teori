(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GameList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FRONTEND/quiz/daftar-game-favorit/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FRONTEND/quiz/daftar-game-favorit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/FRONTEND/quiz/daftar-game-favorit/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function GameList() {
    _s();
    const [games, setGames] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [name, setName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [genre, setGenre] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [rating, setRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [image, setImage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [description, setDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    // ---------------------------------------------------
    // GET DATA DARI API
    // ---------------------------------------------------
    const fetchGames = async ()=>{
        const res = await fetch("/api/games");
        const data = await res.json();
        setGames(data);
        setLoading(false);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameList.useEffect": ()=>{
            const load = {
                "GameList.useEffect.load": async ()=>{
                    const res = await fetch("/api/games");
                    const data = await res.json();
                    setGames(data);
                    setLoading(false);
                }
            }["GameList.useEffect.load"];
            load(); // aman → ini di dalam effect, bukan fungsi luar
        }
    }["GameList.useEffect"], []);
    // ---------------------------------------------------
    // CREATE GAME
    // ---------------------------------------------------
    const addGame = async (e)=>{
        e.preventDefault();
        const newGame = {
            name,
            genre,
            rating,
            image,
            description
        };
        await fetch("/api/games", {
            method: "POST",
            body: JSON.stringify(newGame)
        });
        setName("");
        setGenre("");
        setRating(0);
        setImage("");
        setDescription("");
        fetchGames();
    };
    // ---------------------------------------------------
    // DELETE GAME
    // ---------------------------------------------------
    const deleteGame = async (id)=>{
        await fetch(`/api/games/${id}`, {
            method: "DELETE"
        });
        fetchGames();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container py-4 text-light",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "fw-bold mb-4",
                style: {
                    color: "#b666ff"
                },
                children: "Daftar Game Favorit (Database)"
            }, void 0, false, {
                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                lineNumber: 88,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: addGame,
                className: "card p-4 mb-4",
                style: {
                    background: "#1a1a1a",
                    border: "1px solid #7a00ff",
                    boxShadow: "0 0 10px #7a00ff44"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        style: {
                            color: "#b666ff"
                        },
                        children: "Tambah Game Baru"
                    }, void 0, false, {
                        fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                        lineNumber: 102,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "form-label",
                                children: "Nama Game"
                            }, void 0, false, {
                                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                lineNumber: 105,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                className: "form-control bg-dark text-light",
                                value: name,
                                onChange: (e)=>setName(e.target.value),
                                required: true
                            }, void 0, false, {
                                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                lineNumber: 106,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "form-label",
                                children: "Genre"
                            }, void 0, false, {
                                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                lineNumber: 116,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                className: "form-control bg-dark text-light",
                                value: genre,
                                onChange: (e)=>setGenre(e.target.value),
                                required: true
                            }, void 0, false, {
                                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                lineNumber: 117,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                        lineNumber: 115,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "form-label",
                                children: "Rating (1 - 10)"
                            }, void 0, false, {
                                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                lineNumber: 127,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                className: "form-control bg-dark text-light",
                                value: rating,
                                onChange: (e)=>setRating(Number(e.target.value)),
                                required: true
                            }, void 0, false, {
                                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                lineNumber: 128,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "form-label",
                                children: "Image URL"
                            }, void 0, false, {
                                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                lineNumber: 138,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                className: "form-control bg-dark text-light",
                                value: image,
                                onChange: (e)=>setImage(e.target.value),
                                placeholder: "https://example.com/image.jpg"
                            }, void 0, false, {
                                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                lineNumber: 139,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                        lineNumber: 137,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "form-label",
                                children: "Deskripsi"
                            }, void 0, false, {
                                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                lineNumber: 149,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                className: "form-control bg-dark text-light",
                                value: description,
                                onChange: (e)=>setDescription(e.target.value)
                            }, void 0, false, {
                                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                lineNumber: 150,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                        lineNumber: 148,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "btn btn-primary",
                        style: {
                            background: "#7a00ff"
                        },
                        children: "Simpan Game"
                    }, void 0, false, {
                        fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                        lineNumber: 157,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, this),
            loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Loading..."
            }, void 0, false, {
                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                lineNumber: 164,
                columnNumber: 9
            }, this) : games.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Belum ada game disimpan."
            }, void 0, false, {
                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                lineNumber: 166,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "row",
                children: games.map((game)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-md-4 mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "card p-3 text-light",
                            style: {
                                background: "#222",
                                border: "1px solid #7a00ff",
                                boxShadow: "0 0 10px #7a00ff55"
                            },
                            children: [
                                game.image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: game.image,
                                    alt: game.name,
                                    className: "img-fluid rounded mb-3",
                                    style: {
                                        height: "150px",
                                        objectFit: "cover"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                    lineNumber: 180,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                    style: {
                                        color: "#b666ff"
                                    },
                                    children: game.name
                                }, void 0, false, {
                                    fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                    lineNumber: 188,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-secondary",
                                    children: game.genre
                                }, void 0, false, {
                                    fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                    lineNumber: 189,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        "⭐ ",
                                        game.rating,
                                        "/10"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                    lineNumber: 190,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    style: {
                                        fontSize: "14px"
                                    },
                                    children: [
                                        game.description?.substring(0, 80),
                                        "..."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                    lineNumber: 192,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>deleteGame(game.id),
                                    className: "btn btn-danger btn-sm mt-3",
                                    children: "Hapus"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                    lineNumber: 196,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: `/games/edit/${game.id}`,
                                    className: "btn btn-warning btn-sm mt-2",
                                    children: "Edit"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                    lineNumber: 203,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$FRONTEND$2f$quiz$2f$daftar$2d$game$2d$favorit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: `/games/${game.id}`,
                                    className: "btn btn-info btn-sm mt-2",
                                    children: "Detail"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                                    lineNumber: 207,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                            lineNumber: 171,
                            columnNumber: 15
                        }, this)
                    }, game.id, false, {
                        fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                        lineNumber: 170,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
                lineNumber: 168,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/components/GameList.tsx",
        lineNumber: 86,
        columnNumber: 5
    }, this);
}
_s(GameList, "W3R+STI3K0C45IxkUFh8RBgzMmE=");
_c = GameList;
var _c;
__turbopack_context__.k.register(_c, "GameList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=Documents_FRONTEND_quiz_daftar-game-favorit_app_components_GameList_tsx_e706e3bc._.js.map