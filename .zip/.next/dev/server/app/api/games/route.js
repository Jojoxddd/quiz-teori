var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/games/route.js")
R.c("server/chunks/cf31d_next_c6c25d63._.js")
R.c("server/chunks/[root-of-the-server]__b57132f2._.js")
R.c("server/chunks/5d589_daftar-game-favorit__next-internal_server_app_api_games_route_actions_efd09a3e.js")
R.m("[project]/Documents/FRONTEND/quiz/daftar-game-favorit/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/api/games/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/Documents/FRONTEND/quiz/daftar-game-favorit/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Documents/FRONTEND/quiz/daftar-game-favorit/app/api/games/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
