globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/cf31d_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f78c8f5a._.js",
    "static/chunks/cf31d_next_dist_compiled_react-dom_17995ef7._.js",
    "static/chunks/cf31d_next_dist_compiled_react-server-dom-turbopack_3135ecb8._.js",
    "static/chunks/cf31d_next_dist_compiled_next-devtools_index_3692facb.js",
    "static/chunks/cf31d_next_dist_compiled_0ae7872c._.js",
    "static/chunks/cf31d_next_dist_client_b99f1d8e._.js",
    "static/chunks/cf31d_next_dist_9f372e28._.js",
    "static/chunks/cf31d_@swc_helpers_cjs_aac32042._.js",
    "static/chunks/Documents_FRONTEND_quiz_daftar-game-favorit_a0ff3932._.js",
    "static/chunks/turbopack-Documents_FRONTEND_quiz_daftar-game-favorit_59ed8af5._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];