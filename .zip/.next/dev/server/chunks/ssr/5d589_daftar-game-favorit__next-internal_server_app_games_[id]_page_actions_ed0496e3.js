module.exports = [
"[project]/Documents/FRONTEND/quiz/daftar-game-favorit/.next-internal/server/app/games/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=5d589_daftar-game-favorit__next-internal_server_app_games_%5Bid%5D_page_actions_ed0496e3.js.map