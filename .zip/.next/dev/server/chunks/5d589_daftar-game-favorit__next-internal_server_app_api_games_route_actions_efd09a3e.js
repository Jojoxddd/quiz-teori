module.exports = [
"[project]/Documents/FRONTEND/quiz/daftar-game-favorit/.next-internal/server/app/api/games/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=5d589_daftar-game-favorit__next-internal_server_app_api_games_route_actions_efd09a3e.js.map