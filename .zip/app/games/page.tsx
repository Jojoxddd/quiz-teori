import GameList from "@/components/GameList";

export default function GamesPage() {
  return (
    <div>
      <GameList />
    </div>
  );
}
